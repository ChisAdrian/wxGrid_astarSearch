/***************************************************************
 * Name:      wxGrid_astarSearchMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    Adrian Chis (chis.adrian@gmail.com)
 * Created:   2021-03-17
 * Copyright: Adrian Chis ()
 * License:
 **************************************************************/

#include "wxGrid_astarSearchMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(wxGrid_astarSearchFrame)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(wxGrid_astarSearchFrame)
const long wxGrid_astarSearchFrame::ID_BUTTON1 = wxNewId();
const long wxGrid_astarSearchFrame::ID_GRID1 = wxNewId();
const long wxGrid_astarSearchFrame::ID_BUTTON2 = wxNewId();
const long wxGrid_astarSearchFrame::idMenuQuit = wxNewId();
const long wxGrid_astarSearchFrame::idMenuAbout = wxNewId();
const long wxGrid_astarSearchFrame::ID_STATUSBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(wxGrid_astarSearchFrame,wxFrame)
    //(*EventTable(wxGrid_astarSearchFrame)
    //*)
END_EVENT_TABLE()

wxGrid_astarSearchFrame::wxGrid_astarSearchFrame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(wxGrid_astarSearchFrame)
    wxMenu* Menu1;
    wxMenu* Menu2;
    wxMenuBar* MenuBar1;
    wxMenuItem* MenuItem1;
    wxMenuItem* MenuItem2;

    Create(parent, id, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("id"));
    SetClientSize(wxSize(919,468));
    Button1 = new wxButton(this, ID_BUTTON1, _("Label"), wxPoint(16,8), wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON1"));
    Grid1 = new wxGrid(this, ID_GRID1, wxPoint(24,56), wxSize(856,392), 0, _T("ID_GRID1"));
    Grid1->CreateGrid(100,100);
    Grid1->EnableEditing(true);
    Grid1->EnableGridLines(true);
    Grid1->SetDefaultCellFont( Grid1->GetFont() );
    Grid1->SetDefaultCellTextColour( Grid1->GetForegroundColour() );
    ButtonX = new wxButton(this, ID_BUTTON2, _("x"), wxPoint(128,8), wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON2"));
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1, idMenuQuit, _("Quit\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About\tF1"), _("Show info about this application"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Help"));
    SetMenuBar(MenuBar1);
    StatusBar1 = new wxStatusBar(this, ID_STATUSBAR1, 0, _T("ID_STATUSBAR1"));
    int __wxStatusBarWidths_1[1] = { -1 };
    int __wxStatusBarStyles_1[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,__wxStatusBarWidths_1);
    StatusBar1->SetStatusStyles(1,__wxStatusBarStyles_1);
    SetStatusBar(StatusBar1);

    Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&wxGrid_astarSearchFrame::OnButton1Click);
    Connect(ID_BUTTON2,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&wxGrid_astarSearchFrame::OnButtonXClick);
    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&wxGrid_astarSearchFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&wxGrid_astarSearchFrame::OnAbout);
    Connect(wxEVT_SIZE,(wxObjectEventFunction)&wxGrid_astarSearchFrame::OnResize1);
    //*)
}

wxGrid_astarSearchFrame::~wxGrid_astarSearchFrame()
{
    //(*Destroy(wxGrid_astarSearchFrame)
    //*)
}

void wxGrid_astarSearchFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void wxGrid_astarSearchFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}


#include "astarsearch.h"


void display_aStar_Path(wxGrid * grid,aStar_Path p, wxString colortxt)
{
    for(size_t sz =0; sz<p.size(); sz++)
    {
        int r = p.at(sz).at(0);
        int c = p.at(sz).at(1);
        int r_min_1 = 0;
        int c_min_1 = 0;

        if(sz>0)
        {
            r_min_1 = p.at(sz-1).at(0);
            c_min_1 =  p.at(sz-1).at(1);
        }
         auto c_cell_val = grid->GetCellValue(r,c);
        //grid->SetCellValue(r,c,"w");

        if(r_min_1 >r )
             grid->SetCellValue(r,c,c_cell_val + L" ↓");

        if(r_min_1 <r )
             grid->SetCellValue(r,c,c_cell_val + L" ↑");

        if(c_min_1 > c)
            grid->SetCellValue(r,c,c_cell_val + L" →");

        if(c_min_1 < c)
            grid->SetCellValue(r,c,c_cell_val + L" ←");

        grid->SetCellBackgroundColour(r,c,wxColor(colortxt));
    }
    grid->SetCellBackgroundColour(p.at(0).at(0),p.at(0).at(1),wxColor("Yellow"));
    grid->SetCellBackgroundColour(p.at(p.size()-1).at(0),p.at(p.size()-1).at(1),wxColor("Red"));
    grid->Refresh();

}


 mPath step_node( std::vector<std::vector<int>>  walk_table, std::vector<Pair> picks , Pair start , Pair &endof)
{

    std::vector<mPath> Found;
    std::vector<std::vector<int>>PTH ;

    for(auto i=0;i<picks.size();i++)
    {
        PTH = aStarSearch (walk_table, start,picks.at(i));
        Found.push_back(PTH);
    }

    size_t init_s = 0;
    int index_of_min ;
    for (int i = Found.size() - 1;i>= 0; --i)
    {
        if(init_s==0)
        {
            init_s = Found.at(i).size();
            index_of_min = i;
        }
        if( Found.at(i).size() < init_s)
        {
            init_s  =  Found.at(i).size();
            index_of_min = i;

        }
    }


    endof = std::make_pair(Found.at(index_of_min).at(0).at(0) ,Found.at(index_of_min).at(0).at(1));
    return Found.at(index_of_min);

}


void remove_found_node(std::vector<Pair> &All_Nodes , Pair endof)
{
    for(auto i = 1; i< All_Nodes.size();i++)
    {
        for(size_t l=0;l<All_Nodes.size();l++)
        {
            if (endof == All_Nodes[l])
                All_Nodes.erase(All_Nodes.begin()+ int(l));
        }
    }
}

  std::vector<mPath> Colect_Route
  (std::vector<std::vector<int>> walk_table ,
    std::vector<Pair> All_Nodes,Pair  begin_point )
  {


    auto start =  begin_point ;

    std::vector<mPath> Colect_Route;
    Pair endof;
    size_t size_loop = All_Nodes.size();

    for(size_t i=0;i<size_loop;i++ )
    {
        Colect_Route.push_back(step_node(walk_table,All_Nodes,start,endof));
        remove_found_node( All_Nodes ,  endof);
        start = endof;
    }

   return Colect_Route;

  }

  void test_one_step(wxGrid * Grid1, std::vector<std::vector<int>> walk_table,
std::vector<Pair> DEST,Pair start)
  {

    std::vector<mPath>minR = Colect_Route(walk_table,DEST,start );

    size_t loop_minR = minR.size();
      for(auto r = 0;r<loop_minR ;r++)
      {
            auto minPTH =  minR.at(r);
            for (int i = minPTH.size() - 1; i >= 0; --i)
            {

                    auto c_cell_val = Grid1->GetCellValue(minPTH.at(i).at(0), minPTH.at(i).at(1) );
                    if( (i)>0 &&
                        minPTH.at(i-1).at(0) > minPTH.at(i).at(0) )
                            Grid1->SetCellValue(minPTH.at(i).at(0), minPTH.at(i).at(1),c_cell_val + L" ↓");

                    if( (i)>0 &&
                        minPTH.at(i-1).at(0) < minPTH.at(i).at(0) )
                            Grid1->SetCellValue(minPTH.at(i).at(0), minPTH.at(i).at(1),c_cell_val + L" ↑");

                    if( (i)>0 &&
                        minPTH.at(i-1).at(1) < minPTH.at(i).at(1) )
                            Grid1->SetCellValue(minPTH.at(i).at(0), minPTH.at(i).at(1),c_cell_val + L" ←");

                    if( (i)>0 &&
                        minPTH.at(i-1).at(1) > minPTH.at(i).at(1) )
                            Grid1->SetCellValue(minPTH.at(i).at(0), minPTH.at(i).at(1),c_cell_val + L" →");


                Grid1->SetCellBackgroundColour(minPTH.at(i).at(0), minPTH.at(i).at(1),wxColor("Green"));

            }
      }

    Grid1->AutoSizeColumns();
    Grid1->Refresh();
  }


// by second element of pairs
bool sortby_second(const std::pair<int,int> &a,
              const std::pair<int,int> &b)
{
    return (a.second < b.second);
    // && a.first < b.first
}

// by fisrt element of pairs
bool sortby_first(const std::pair<int,int> &a,
              const std::pair<int,int> &b)
{
    return (a.first < b.first);
    // && a.first < b.first
}


void wxGrid_astarSearchFrame::OnButton1Click(wxCommandEvent& event)
{
     std::vector<std::vector<int>> walk_table
    {
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}

    };


    for(int i=0;i<walk_table.size();i++ )
    {
         for(int c=0;c<walk_table.at(0).size();c++ )
         {
             Grid1->SetCellValue(i,c, wxString::FromDouble( walk_table[i][c])  );
             if(  walk_table[i][c] == 0) Grid1->SetCellBackgroundColour(i,c, wxColor("Black"));
             if(  walk_table[i][c] == 1) Grid1->SetCellValue(i,c, "");
         }
    }

     for(int c=0;c<walk_table.at(0).size();c++ )
        Grid1->SetColLabelValue(c,wxString::FromDouble(c,0));

    for(int i=0;i<walk_table.size();i++ )
        Grid1->SetRowLabelValue(i,wxString::FromDouble(i,0));


        Grid1->AutoSizeColumns();

     //  return;
        std::vector<Pair> pick_point;

        // Optim in this case because next column have row 1

pick_point.push_back(std::make_pair(4,3));
pick_point.push_back(std::make_pair(13,3));
pick_point.push_back(std::make_pair(23,3));
pick_point.push_back(std::make_pair(9,6));
pick_point.push_back(std::make_pair(20,6));
pick_point.push_back(std::make_pair(3,9));
pick_point.push_back(std::make_pair(5,9));
pick_point.push_back(std::make_pair(15,9));
pick_point.push_back(std::make_pair(1,12));
pick_point.push_back(std::make_pair(18,12));
pick_point.push_back(std::make_pair(23,12));
pick_point.push_back(std::make_pair(2,15));
pick_point.push_back(std::make_pair(22,15));


         std::vector<Pair> DEST;
        auto start = std::make_pair(0, 1);

         for(size_t i=0;i<pick_point.size();i++)
         {
            DEST.push_back(std::make_pair(pick_point[i].first,pick_point[i].second));
            test_one_step(Grid1,walk_table,DEST,start);
            start = DEST[0];
            DEST.clear();

         }

     for(size_t i=0;i<pick_point.size();i++)
     {
         Grid1->SetCellValue(pick_point[i].first,pick_point[i].second,"-P-" + std::to_string(i)  );
         Grid1->SetCellBackgroundColour(pick_point[i].first,pick_point[i].second,
                                        wxColor("Red"));
     }
Grid1->AutoSizeColumns();
}

void wxGrid_astarSearchFrame::OnGrid1Resize(wxSizeEvent& event)
{
  return;
}

void wxGrid_astarSearchFrame::OnResize1(wxSizeEvent& event)
{
        int width,height;
    this->GetClientSize(&width,&height);
    Grid1->SetSize(16,72,width-30,height - 72 - 30);
}


aStar_Path connect_rows( std::vector<std::vector<int>> walk_table,std::vector<Pair> prev_row ,std::vector<Pair> pick_point )
{
    size_t mins = 0;
        aStar_Path leave_row;

         for(size_t ppr =0 ;ppr<prev_row.size();ppr++)
         {
            for(size_t pr =0 ;pr<pick_point.size();pr++)
            {
                aStar_Path s_Path = aStarSearch(walk_table,prev_row.at(ppr),pick_point.at(pr));

                 if(pr ==0)
                 {
                     mins = s_Path.size();
                     leave_row = s_Path;
                 }

                if(s_Path.size()< mins)
                {
                    leave_row = s_Path;
                    mins = s_Path.size();

                }

            }
        }

    return leave_row;
}


void pick_point_min_max(  std::vector<Pair> in ,

 std::pair<int,int> &pmin,   std::pair<int,int> &pmax  )
{
    sort(in.begin(), in.end(), sortby_first);

    pmin = in.front();
    pmax = in.back();
    return ;

}


void wxGrid_astarSearchFrame::OnButtonXClick(wxCommandEvent& event)
{

    Grid1->ClearGrid();
    for (int i=0; i<Grid1->GetNumberCols(); i++)
for (int j=0; j<Grid1->GetNumberRows(); j++)
Grid1->SetCellBackgroundColour(i, j, wxColour("LIGHT GREY"));
    Grid1->Refresh();

         std::vector<std::vector<int>> walk_table
    {
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}, //
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}

    };


    for(int i=0;i<walk_table.size();i++ )
    {
         for(int c=0;c<walk_table.at(0).size();c++ )
         {
             Grid1->SetCellValue(i,c, wxString::FromDouble( walk_table[i][c])  );
             if(  walk_table[i][c] == 0) Grid1->SetCellBackgroundColour(i,c, wxColor("Black"));
             if(  walk_table[i][c] == 1) Grid1->SetCellValue(i,c, "");
         }
    }

     for(int c=0;c<walk_table.at(0).size();c++ )
        Grid1->SetColLabelValue(c,wxString::FromDouble(c,0));

    for(int i=0;i<walk_table.size();i++ )
        Grid1->SetRowLabelValue(i,wxString::FromDouble(i,0));



        Grid1->AutoSizeColumns();

       //  rand()%(23-1 + 1) + 1;

        std::vector<Pair> pick_points;
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,3));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,3));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,3));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,6));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,6));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,6));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,6));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,9));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,9));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,9));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,12));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,12));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,12));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,15));
pick_points.push_back(std::make_pair(rand()%(23-1 + 1) + 1,15));



        sort(pick_points.begin(), pick_points.end(), sortby_second);

        std::vector<Pair> pick_point_col;
        std::vector<std::vector<Pair>>pick_points_rows;

        int row = pick_points.front().second;
         for(auto p : pick_points)
        {
            if(p.second > row)
            {
                pick_points_rows.push_back(pick_point_col);
                pick_point_col.clear();
                row = p.second;
            }
            if(p.second == row)
                pick_point_col.push_back(p);
        }
         pick_points_rows.push_back(pick_point_col);
        pick_point_col.clear();


        std::vector<Pair> start_row;
        start_row.push_back(std::make_pair(0,0));
         std::vector<Pair> to_row;
        //bool v_begin = false;
         bool v_begin = true;

        for(auto pk : pick_points_rows)
        {
           //wxMessageBox(wxString::FromDouble(pk.size()));
                std::pair<int,int> pmin;
                std::pair<int,int> pmax;
                pick_point_min_max(pk,pmin,pmax);
                to_row.clear();
                to_row.push_back(pmin);
                to_row.push_back(pmax);

                aStar_Path min_path = aStarSearch(walk_table,start_row.front(),to_row.front());


                    auto conn_path = aStarSearch(walk_table,start_row.back(),to_row.front());
                    if(conn_path.size() <= min_path.size())
                    {
                        min_path = conn_path;
                    }

                    conn_path=aStarSearch(walk_table,start_row.front(),to_row.back());
                    if(conn_path.size() <= min_path.size())
                    {
                        min_path = conn_path;
                    }

                    conn_path=aStarSearch(walk_table,start_row.back(),to_row.back());
                    if(conn_path.size() <= min_path.size())
                    {
                        min_path = conn_path;
                    }
                    display_aStar_Path(Grid1,min_path,"Green");

                    start_row.clear();
                    start_row = to_row;
        }

    for(auto ph : pick_points)
    {
         if(Grid1->GetCellValue(ph.first,ph.second) == "")
         {
               Grid1->SetCellValue(ph.first,ph.second,"-P-");

         }
           Grid1->SetCellValue(ph.first,ph.second,"-P-");
  Grid1->SetCellBackgroundColour(ph.first,ph.second,wxColor("Red"));
    }
    Grid1->AutoSizeColumns();

    //wxMessageBox(for_msg);
}
